﻿function OpenModal(modal) {
    modal.style.display = "block";
}

// We want the modal to close when the OK button is clicked
function CloseModal(modal) {
    modal.style.display = "none";
}